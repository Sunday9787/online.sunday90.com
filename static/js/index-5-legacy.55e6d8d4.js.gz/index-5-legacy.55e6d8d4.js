System.register([],(function(e,t){"use strict";return{execute:function(){e("c",new Map)}}}));
//# sourceMappingURL=index-5-legacy.55e6d8d4.js.map
