import{n as t}from"./vendor.e75a9f0e.js";import"./libs.ec5fd20d.js";const a=t({name:"CanvasIndex"},(function(){var t=this._self._c;return t("app-page",[t("app-card",[t("router-link",{attrs:{to:"/canvas/sem"}},[t("el-button",{attrs:{type:"primary"}},[this._v("SEM")])],1)],1)],1)}),[],!1,null,null,null,null).exports;export{a as default};
//# sourceMappingURL=canvas.e20439c3.js.map
